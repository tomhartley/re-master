from stitch import *
import linefinder
import cv2
import numpy as np
import os

cap = cv2.VideoCapture(0)

ret, img = cap.read()

lines, img = linefinder.getLines(img)
#div by 15 to get something that fits.
lines = map(lambda (start,end): (start/7,end/7), lines)
#print lines
stitchpoints = []

stitchlines = []

for line in lines:
    beginning = line[0]
    vector = line[1]-line[0]
    len = np.linalg.norm(vector)
    numstitches = int(len*2)
    sts = []
    for i in range(0,numstitches+1):
       sts.append(i*(vector/numstitches)+beginning)
    stitchlines.append(sts)

stitchlist = []
for i in stitchlines:
    s = Stitch(StitchType.jump,i[0]) #jump to the end of the first stich, so it'll stitch in place
    stitchlist.append(s)
    stitchlist+=map(lambda l: Stitch(StitchType.stitch,l),i)

#stitchlist.append(Stitch(StitchType.jump,[0,0]))
minimiseDesign(stitchlist)
if (not checkDesign(stitchlist)):
    print "Design may be too large for machine"
else:
    print "Design is correct size"
writeStitches(stitchlist,'csv_out/output.csv')

os.system("./libembroidery-convert csv_out/output.csv pes_out/output.pes")

cv2.imshow("Output",img)

cv2.waitKey(0)
